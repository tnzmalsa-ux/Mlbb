# MLBB Offline Demo (Android)

A standalone Android demonstration app with simulated unlimited diamonds, simulated Battle Points, and a sample skin shop. It does **not** connect to or modify Mobile Legends: Bang Bang.

## Build with Android Studio
1. Install Android Studio and an Android SDK (API 35 or a compatible newer SDK).
2. Open this folder as an existing Gradle project.
3. Allow Gradle sync to complete.
4. Select **Build > Build APK(s)**.
5. Find the APK under `app/build/outputs/apk/debug/`.

## Notes
- Package: `com.example.mlbbdemo`
- Minimum Android version: Android 6.0 (API 23)
- No account login, network permission, or MLBB game-file modification.
- This is source code, not a precompiled APK. The APK is produced by building the project.
