package com.example.mlbbdemo;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(10, 16, 34);
    private final int panel = Color.rgb(22, 32, 58);
    private final int gold = Color.rgb(255, 205, 92);
    private LinearLayout content;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(content);
        setContentView(scroll);

        addText("MLBB  •  OFFLINE DEMO", 13, gold, true);
        addText("Diamond Vault", 30, Color.WHITE, true);
        addText("A standalone currency and skin-shop preview", 14, 0xFFB9C5DD, false);
        addSpace(22);

        addBalance("💎", "DIAMONDS", "999,999,999");
        addSpace(12);
        addBalance("🪙", "BATTLE POINTS", "999,999,999");
        addSpace(20);

        addText("DEMO SKIN SHOP", 15, gold, true);
        addText("These are sample items for this offline demo only.", 13, 0xFFB9C5DD, false);
        addSpace(10);
        addSkin("Celestial Warrior", "Epic • Demo skin");
        addSkin("Shadow Assassin", "Legendary • Demo skin");
        addSkin("Ocean Guardian", "Special • Demo skin");

        addSpace(18);
        addText("INVENTORY", 15, gold, true);
        addText("3 demo skins available", 16, Color.WHITE, true);
        addSpace(20);
        TextView note = addText("DEMO ONLY — This app does not connect to, modify, or add currency to the official Mobile Legends game. No MLBB login is needed.", 12, 0xFF9EABC6, false);
        note.setPadding(dp(14), dp(14), dp(14), dp(14));
        note.setBackground(round(panel, 14));
    }

    private void addBalance(String emoji, String label, String amount) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(round(panel, 18));
        TextView top = new TextView(this);
        top.setText(emoji + "   " + label);
        top.setTextColor(0xFFB9C5DD);
        top.setTextSize(13);
        top.setTypeface(null, Typeface.BOLD);
        card.addView(top);
        TextView value = new TextView(this);
        value.setText(amount);
        value.setTextColor(Color.WHITE);
        value.setTextSize(29);
        value.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.topMargin = dp(8);
        card.addView(value, vp);
        TextView sub = new TextView(this);
        sub.setText("UNLIMITED DEMO BALANCE");
        sub.setTextColor(gold);
        sub.setTextSize(10);
        sub.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(5);
        card.addView(sub, sp);
        content.addView(card, match());
    }

    private void addSkin(String name, String detail) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(12), dp(12));
        row.setBackground(round(panel, 14));
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText(name);
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setTypeface(null, Typeface.BOLD);
        left.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText(detail);
        subtitle.setTextColor(0xFFB9C5DD);
        subtitle.setTextSize(12);
        left.addView(subtitle);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        Button unlocked = new Button(this);
        unlocked.setText("UNLOCKED");
        unlocked.setTextSize(10);
        unlocked.setTextColor(bg);
        unlocked.setAllCaps(false);
        unlocked.setBackground(round(gold, 10));
        unlocked.setOnClickListener(v -> Toast.makeText(this, "Demo item already unlocked", Toast.LENGTH_SHORT).show());
        row.addView(unlocked);
        LinearLayout.LayoutParams p = match();
        p.bottomMargin = dp(9);
        content.addView(row, p);
    }

    private TextView addText(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        content.addView(v, match());
        return v;
    }
    private void addSpace(int h) {
        View v = new View(this);
        content.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
